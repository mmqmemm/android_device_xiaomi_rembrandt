#!/bin/bash

# Clear the screen for better visibility
clear

# Define paths
SCRIPT_PATH="$(cd "$(dirname "$0")" && pwd)"
fastboot="$SCRIPT_PATH/tools/linux/fastboot"
imagesPath="$SCRIPT_PATH/images"

# Check if fastboot exists and is executable
if [ ! -f "$fastboot" ]; then
    printf "%s not found.\n" "$fastboot"
    exit 1
fi

if [ ! -x "$fastboot" ]; then
    chmod +x "$fastboot" || { printf "%s cannot be executed.\n" "$fastboot"; exit 1; }
fi

# Ask the user if they want to format data
printf "Do you want to format data? (Y/N): "
read -r formatData

if [[ "$formatData" =~ ^[Yy]$ ]]; then
    printf "Formatting data...\n"
    "$fastboot" erase metadata
    "$fastboot" erase userdata
    "$fastboot" erase frp
    printf "Data formatted successfully.\n"
else
    printf "Skipping data formatting.\n"
fi

# Navigate to the images directory
if [ ! -d "$imagesPath" ]; then
    printf "Images directory %s not found. Aborting.\n" "$imagesPath"
    exit 1
fi
cd "$imagesPath" || exit 1

# Verify critical images
printf "Verifying critical images...\n"

requiredImages=(
    "apusys.img" "audio_dsp.img" "boot.img" "ccu.img" "dpm.img" "dtbo.img"
    "gpueb.img" "gz.img" "lk.img" "mcf_ota.img" "mcupm.img" "md1img.img"
    "mvpu_algo.img" "pi_img.img" "scp.img" "spmfw.img" "sspm.img" "tee.img"
    "vcp.img" "vbmeta.img" "vendor_boot.img" "vbmeta_system.img" "vbmeta_vendor.img"
)

additionalRequiredFiles=(
    "super.img" "preloader_plato.bin"
)

# Check for missing images
missingImages=()
for img in "${requiredImages[@]}" "${additionalRequiredFiles[@]}"; do
    if [ ! -f "$img" ]; then
        missingImages+=("$img")
    fi
done

if [ "${#missingImages[@]}" -ne 0 ]; then
    printf "Missing critical images:\n"
    for img in "${missingImages[@]}"; do
        printf " - %s\n" "$img"
    done

    printf "Some required images are missing. Do you want to continue anyway? (Type 'yes' to continue): "
    read -r continue
    if [ "$continue" != "yes" ]; then
        printf "Aborting flash process.\n"
        exit 1
    fi
fi

# Start flashing process
printf "Starting the flashing process...\n"

# Flash preloader image if available
if [ -f "preloader_plato.bin" ]; then
    "$fastboot" flash preloader1 preloader_plato.bin
    "$fastboot" flash preloader2 preloader_plato.bin
fi

# Flash each required image
for img in "${requiredImages[@]}"; do
    if [ -f "$img" ]; then
        partition_name="${img%.*}_a"
        "$fastboot" flash "$partition_name" "$img"
    fi
done

# Flash super image if available
if [ -f "super.img" ]; then
    "$fastboot" flash super super.img
fi

# Set the active slot to "a"
printf "Setting active slot...\n"
"$fastboot" set_active a
printf "Slot 'a' activated successfully.\n"

# Complete the process
printf "Flashing process completed. Rebooting...\n"
"$fastboot" reboot
sleep 5

exit 0
